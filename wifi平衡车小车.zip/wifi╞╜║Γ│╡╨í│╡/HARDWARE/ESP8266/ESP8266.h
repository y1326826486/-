#ifndef __ESP8266_H
#define __ESP8266_H 
#include "sys.h"	  	

extern u8 Usart3_Receive;
void ESP8266_init(u32 bound);
void USART3_IRQHandler(void);
void Uart3SendByte(char byte);   //串口发送一个字节
void Uart3SendBuf(char *buf, u16 len);
void Uart3SendStr(char *str);

#endif
