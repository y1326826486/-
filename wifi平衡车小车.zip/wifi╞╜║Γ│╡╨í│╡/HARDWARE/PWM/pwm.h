#ifndef  _PWM_H
#define  _PWM_H

#include "sys.h" 



void PWM_Init_TIM1(u16 Psc,u16 Per);
#endif
