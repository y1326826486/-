#ifndef __LED_H
#define __LED_H

#include "sys.h"

#define LED_ON GPIO_ResetBits(GPIOC,GPIO_Pin_13)
#define LED_OFF GPIO_SetBits(GPIOC,GPIO_Pin_13) 
void LED_Init(void);

#endif
